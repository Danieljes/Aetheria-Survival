#version 150
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;

    // Focus op het gebied waar het scoreboard meestal zit
    if (
        gl_Position.y > -0.5 && gl_Position.y < 0.85 &&
        gl_Position.x > 0.40 && gl_Position.x <= 1.0
    ) {
        // 🌫️ Grijstint afhankelijk van z-diepte
        float zDepth = clamp(1.0 - abs(gl_Position.z / 2.0), 0.0, 1.0);
        vertexColor.rgb = vec3(zDepth); // Lichter = dichter bij z = 0
        vertexColor.a = 1.0;

        // 🫥 Maak transparant in brede z-range van –2.0 tot +2.0
        if (gl_Position.z > -2.0 && gl_Position.z < 2.0) {
            vertexColor.a = 0.0;
        }
    }
}
