#version 150
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;
uniform vec2 ScreenSize;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float fog_spherical_distance(vec3 pos) {
    // Replace with your actual fog function or import
    return length(pos);
}

float fog_cylindrical_distance(vec3 pos) {
    // Replace with your actual fog function or import
    return length(pos.xz);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    // delete sidebar numbers
    if (
        gl_Position.x >= 0.95 && gl_Position.y >= -0.35 &&
        vertexColor.g == 84.0/255.0 && vertexColor.b == 84.0/255.0 && vertexColor.r == 252.0/255.0
    ) {
        vertexColor.a = 0;
    }

    if (
        gl_VertexID >= 1 &&
        gl_Position.y > -0.5 && gl_Position.y < 0.85 &&
        gl_Position.x > 0.60 && gl_Position.x <= 1.0 &&
        gl_Position.z < -0.2 && gl_Position.z > -0.3
    ) {
        gl_Position.z = -1;
    }
}
